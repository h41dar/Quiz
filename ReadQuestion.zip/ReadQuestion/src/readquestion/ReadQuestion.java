/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package readquestion;

import java.util.Scanner;

/**
 *
 * @author h41dar21
 */
public class ReadQuestion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       // Question q = new Question();
       // Scanner input = new Scanner(System.in);
       
        
        //new ReadInputFrame().setVisible(true);
        
         //Question array[] = q.getQuestion_file("test");
        //System.out.println(array.length);
        
//        for (int i = 0; i < array.length; i++) {
//          //   array[i].display();
//            
//        }
        
       //new ReadInputFrame().setVisible(true);
        
        new exams().setVisible(true);
        

      
        
    }
    
}
