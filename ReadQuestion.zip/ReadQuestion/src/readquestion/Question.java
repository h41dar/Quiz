/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readquestion;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;


/**
 *
 * @author h41dar21
 */
public class Question {
    
    private int defalt_choice =4;
     String question  ,answer ;
     String choice[] = new String[defalt_choice] ;

    public String getQuestion() {
        return question;
    }
    

    public Question() {
    }

    public Question(String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public void setDefalt_choice(int defalt_choice) {
        this.defalt_choice = defalt_choice;
    }
    
     public boolean check(int c) {
        return answer.equals(choice[c-1]);
    }
     
    public  Question readInput(){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the question");
        question = input.nextLine();
        System.out.println("Enter the answer");
        answer = input.nextLine();
        
        for (int i = 0; i < choice.length; i++) {
            System.out.println("Enter the choice :"+(1+i));
             choice[i] =input.nextLine();
            
        }
        
        return this;
    }
    
    public void printQuestion(){
        System.out.println(question);
        for(int i = 0; i < choice.length; i++) {
             System.out.println(1+i + "." +choice[i]);
            
            
        }
    }

    
    
    public void display(){
        System.out.println(question);
        System.out.println(answer);
        for(int i = 0; i < choice.length; i++) {
             System.out.println(1+i + "." +choice[i]);
        
    }
    
}
    
    public Question[] getQuestion_file(String text){
        text = text + ".txt";
        String line ;
        
        ArrayList<String> input = new ArrayList();
        
        BufferedReader fetch;
        try {
            fetch = new BufferedReader(new FileReader("/Users/h41dar21/my_projects/java/ReadQuestion/quizzes/"+text));
            
            
            while( (line = fetch.readLine()) != null){
               
                input.add(line);
            }
        }catch (Exception ex) {
            ex.getMessage();
        }
        
      
       Question array[] = new Question[input.size()/6];
       
         
     
       for (int i = 0; i < input.size()/6; i++) {
            array[i] = new Question();
            
            
            array[i].question = input.get(0 + (6*i));
            array[i].answer   = input.get(1 + (6*i));
            
            array[i].choice[0] = input.get(2 + (6*i));
            array[i].choice[1] = input.get(3 + (6*i));
            array[i].choice[2] = input.get(4 + (6*i));
            array[i].choice[3] = input.get(5 + (6*i));
            
           
                       
        }
       

         return  array ;
    }
    

   

    @Override
    public String toString() {
        return "Question{" + "question=" + question + ", answer=" + answer + ", choice=" + choice + '}';
    }
}