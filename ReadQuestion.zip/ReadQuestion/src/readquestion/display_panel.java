/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readquestion;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author h41dar21
 */
public class display_panel extends JPanel {
    JPanel up,down ,south , west , mulChoice   ; 
         
    JButton next , previous , check;
    
    JLabel question , space; 
    
    ButtonGroup group;
    
    JRadioButton  choice1R, choice2R, choice3R, choice4R , incorrect ;
    int           index=0 ,number_of_quetion ;
    
    String quiz;
    
    //ReadInputFrame getQuestion = new ReadInputFrame();
    
    public display_panel(String quiz) {
        this.quiz = quiz;
        number_of_quetion = test(quiz).length;
        
        
//        setTitle("Read input");
//        setSize(400, 450);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(2,1));
        
       // q = getQuestion.getQueArray();
        
        
        up       = new JPanel();
        up.setBackground(Color.WHITE);
        up.setLayout(new BorderLayout());
        
        down   = new JPanel();
        down.setLayout(new BorderLayout());
        
        
        south = new JPanel();
        south.setLayout(new BorderLayout());
        west = new JPanel();
        
        
        mulChoice = new JPanel();
        mulChoice.setLayout(new GridLayout(4,1 ,10,5));
        
        
        
        
        previous = new JButton("Previous");
        previous.addActionListener(new previous());
        
        check = new JButton("check");
        check.addActionListener(new check());
        
        next = new JButton("next");
        next.addActionListener(new next());
        
        
        
        Question test[] =test(quiz);
        question = new JLabel(test[index].question);
        choice1R = new JRadioButton(test[index].choice[0]);
        choice2R = new JRadioButton(test[index].choice[1]);
        choice3R = new JRadioButton(test[index].choice[2]);
        choice4R = new JRadioButton(test[index].choice[3]);
        incorrect= new JRadioButton("incorrect");
        
          group = new ButtonGroup();
        
        group.add(choice1R);
        group.add(choice2R);
        group.add(choice3R);
        group.add(choice4R);
        
        
        add(up);
        add(down);
        
        
        
        up.add(question );
        
        
        
        down.add(south , BorderLayout.SOUTH);
        down.add(west  , BorderLayout.WEST);
        
        
        west.add(mulChoice);
        mulChoice.add(choice1R);
        mulChoice.add(choice2R);
        mulChoice.add(choice3R);
        mulChoice.add(choice4R);
        
        south.add(previous , BorderLayout.WEST);
        south.add(check    , BorderLayout.CENTER);
        south.add(next     , BorderLayout.EAST);
        
    }
    
    private class next implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            Question test[] =test(quiz);
          if(index < test.length-1){
              index++;
        question.setText(test[index].question);
        choice1R.setText(test[index].choice[0]);
        choice2R.setText(test[index].choice[1]);
        choice3R.setText(test[index].choice[2]);
        choice4R.setText(test[index].choice[3]);
              
        previous.setEnabled(true);
        restart();
        
              
          }
        
    }
    }
    
    private class previous implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            Question test[] =test(quiz);
        if( index> 0){
              index--;
        question.setText(test[index].question);
        choice1R.setText(test[index].choice[0]);
        choice2R.setText(test[index].choice[1]);
        choice3R.setText(test[index].choice[2]);
        choice4R.setText(test[index].choice[3]);
              
        next.setEnabled(true);
       
        restart();
              
          }
        
    }
    }
    
    
    private class check implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            Question test[] =test(quiz);
            
            JRadioButton  answerRadio =which_selecet();
            
             
            
            if(answerRadio.getActionCommand().equals(test[index].answer)){
               up.setBackground(Color.GREEN);
               
            }else{
                up.setBackground(Color.RED);
            }
       
    }
    }
        

    private Question[]  test(String quiz) {
        
        Question test[] = new Question[4];
         Question q = new Question() ;
        
        Question q1 = new Question() ;
        Question q2 = new Question() ;
        Question q3 = new Question() ;
        Question q4 = new Question() ;
        
        q1.question  ="What is your name ?";
        q1.answer    ="Haidar";
        q1.choice[0] ="Haidar";
        q1.choice[1] ="mohammed";
        q1.choice[2] ="haidar";
        q1.choice[3] ="Ali";
        
        test[0]=q1;
        
        q2.question  ="Which code statement will compile ?";
        q2.answer    ="int x = 5";
        q2.choice[0] ="int x = 5";
        q2.choice[1] ="int x = “5” ";
        q2.choice[2] ="int x = 5.0 ";
        q2.choice[3] ="int x = ‘5’ ";
        
        test[1]=q2;
        
        q3.question  ="What is the correct way to declare a variable in Java?";
        q3.answer    ="int x = 10;";
        q3.choice[0] ="int x = 10;";
        q3.choice[1] ="x = 10;";
        q3.choice[2] ="declare x = 10;";
        q3.choice[3] ="var x = 10;";
        
        test[2]=q3;
        
        q4.question  ="What is the difference between a stack and a queue?";
        q4.answer    ="A stack is LIFO and a queue is FIFO";
        q4.choice[0] ="A stack is FIFO and a queue is LIFO";
        q4.choice[1] ="A stack is LIFO and a queue is FIFO";
        q4.choice[2] ="A stack and a queue are both LIFO";
        q4.choice[3] ="A stack and a queue are both FIFO";
        
        test[3]=q4;
        
       
       // return test;
       
       return q.getQuestion_file(quiz);
       
    }
    
    public JRadioButton which_selecet(){
        
        
        if(choice1R.isSelected()){
            return choice1R;
        }else if(choice2R.isSelected()){
            return choice2R;
        }else if(choice3R.isSelected()){
            return choice3R;
        }else if(choice4R.isSelected()){
            return choice4R;
        }else{
            return incorrect;
        }
        
    }
    
    public void restart(){
        up.setBackground(Color.WHITE);
        
         group.clearSelection();
           
        
    }
    
    
}
