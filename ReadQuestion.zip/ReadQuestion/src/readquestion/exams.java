/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readquestion;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author h41dar21
 */
public class exams extends JFrame {
    Home_panal AllQuiz ;
    display_panel test ;
    input_panel input = new input_panel();
    
    public exams() {
        setTitle("quiz app");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        AllQuiz = new Home_panal();
        test = new display_panel("test");
        
        for(int i = 0; i < AllQuiz.Button.length; i++) {
            AllQuiz.Button[i].addActionListener(new addQuiz());
            
        }
        
        add(AllQuiz);
        
        input.finish.addActionListener(new ToHome());  
        
        
        
    }

    
    
    
    
    private class addQuiz implements ActionListener{
        
        //exams frame = new  exams();
        @Override
        public void actionPerformed(ActionEvent e) {
        remove(AllQuiz);
        test = new display_panel(e.getActionCommand());
        add(test);
        
        revalidate();
        repaint();
        
        test.previous.addActionListener(new Back());  
        test.next.addActionListener(new Home());  
        
        
    }
    
    
  }
    
  

private class Back implements ActionListener{
        
        //exams frame = new  exams();
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println(test.index);
        if(test.index ==0){
        remove(test);
        add(input);
        revalidate();
        repaint(); 
        }    
        
        
          
        
    }
    
    
  }  

private class Home implements ActionListener{
        
        //exams frame = new  exams();
        @Override
        public void actionPerformed(ActionEvent e) {
           
        if(test.index ==test.number_of_quetion-1){
        remove(test);
        add(AllQuiz);
        revalidate();
        repaint(); 
        }    
        
        
          
        
    }
    
    
  } 


  private class ToHome implements ActionListener{
        
        //exams frame = new  exams();
        @Override
        public void actionPerformed(ActionEvent e) {
           
        if(input.quesArrList.isEmpty()){
        remove(input);
        add(AllQuiz);
        revalidate();
        repaint(); 
        }    
        
        
          
        
    }
    
    
  }  
    
}    
    
