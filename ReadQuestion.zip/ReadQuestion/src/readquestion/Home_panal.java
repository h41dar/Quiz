/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readquestion;






import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author h41dar21
 */
public class Home_panal extends JPanel{
    JButton Button[];
    public Home_panal() {
        ArrayList<String> button_name = new ArrayList();
        try {
            //Scanner scan = new Scanner(new File("quizzes_names.txt"));
            BufferedReader fetch = new BufferedReader(new FileReader("quizzes_names.txt"));
            
            
            
            String name ;
            while( (name = fetch.readLine()) != null){
               button_name.add(name);
            }
            
            Button = new  JButton[button_name.size()];
            
            for (int i = 0; i < button_name.size(); i++) {
                Button[i] = new JButton(button_name.get(i));
                
            }
            
            
            fetch.close();
        } catch (Exception ex) {
            ex.getMessage();
        }
        
        for(int i = 0; i < Button.length; i++) {
           this.add(Button[i]) ;
            
        }
        
            
    }

    
}
