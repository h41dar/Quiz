/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readquestion;


import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;

import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author h41dar21
 */
public class input_panel extends JPanel implements ActionListener{
    JLabel     nameLabel , questionLabel , answerLabel ,choice1Label, choice2Label ,choice3Label ,choice4Label ; 
    JTextField nameField , questionField , answerField ,choice1Field, choice2Field ,choice3Field ,choice4Field ;
    JButton    enter     ,finish ;
    Question[] queArray;
// ----------------------------------------------------    

// ----------------------------------------------------    
    ArrayList<Question> quesArrList = new ArrayList<>();
    
    
    
    public input_panel() {
//        setTitle("Read input");
          setSize(400, 400);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
          setLayout(new GridLayout(8, 1));
        
        
       nameLabel     = new JLabel("name:");
       questionLabel = new JLabel("question:");
       answerLabel   = new JLabel("answer:  ");
       choice1Label  = new JLabel("choice :1");
       choice2Label  = new JLabel("choice :2");
       choice3Label  = new JLabel("choice :3");
       choice4Label  = new JLabel("choice :4");
       
       
       nameField     = new JTextField("",12);
       questionField = new JTextField("",12);
       answerField   = new JTextField("",12);
       choice1Field  = new JTextField("",12);
       choice2Field  = new JTextField("",12);
       choice3Field  = new JTextField("",12);
       choice4Field  = new JTextField("",12);
       
       enter = new JButton("Enter");
       enter.addActionListener(this);
       
       finish = new JButton("Finish");
       finish.addActionListener(this);
       
       add(nameLabel);
       add(nameField);
       
       add(questionLabel);
       add(questionField);
       
       add(answerLabel);
       add(answerField);
       
       add(choice1Label);
       add(choice1Field);
       
       add(choice2Label);
       add(choice2Field);
       
       add(choice3Label);
       add(choice3Field);
       
       add(choice4Label);
       add(choice4Field);
       
       add(enter);
       add(finish);
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
        
        if(e.getActionCommand().equals("Finish")){
            
          if(!(nameField.getText().equals("")) && !quesArrList.isEmpty() ){
              try {
                  BufferedWriter writer = new BufferedWriter(new FileWriter("quizzes_names.txt",true));
                  writer.write(nameField.getText());
                  writer.newLine();
                  writer.close();
              } catch (Exception ex) {
                  ex.getMessage();
              }
             
            
            //quesArrList.add(returnQuestion());
            queArray =toarray();
            save_in_file(queArray ,nameField.getText() );
            
            nameField.setText("");
            quesArrList.clear();
          }else if(!quesArrList.isEmpty()){
            JOptionPane.showMessageDialog(new input_panel(), "you have to fill name field");
    
          }
            
            
      
        } else if(e.getActionCommand().equals("Enter")){
            
            if(validation()){
                quesArrList.add(returnQuestion());
            }else{
                JOptionPane.showMessageDialog(new input_panel(), " you have to fill all field");
            }
                
        }
        
    }
    
    public Question returnQuestion() {
        
        Question q = new  Question();
         
        
         q.question  = questionField.getText();
       
         questionField.setText("");
       
         q.answer    = answerField.getText();
       
         answerField.setText("");
       
         q.choice[0] = choice1Field.getText();
       
         choice1Field.setText("");
       
         q.choice[1] = choice2Field.getText();
       
         choice2Field.setText("");
       
         q.choice[2] = choice3Field.getText();
       
         choice3Field.setText("");
       
         q.choice[3] = choice4Field.getText();
       
         choice4Field.setText("");
        
         return q;
        
    }
    
    private Question[] toarray() {
        
        Question q[] = new Question[quesArrList.size()];
        for (int i = 0; i < quesArrList.size(); i++) {
              
              q[i] =  quesArrList.get(i);
              
        }
       
        return q;
    }
    
    public Question[] getQueArray() {
        return queArray;
    }
    
    public void printTest() {
        for(int i = 0; i < queArray.length; i++) {
           queArray[i].display();
        }
        
    }
    
    public boolean validation(){
        
        if(questionField.getText().equals("")){
            return false ;
        }else if(answerField.getText().equals("")){
            return false ;
        }else if(choice1Field.getText().equals("")){
            return false ;
        }else if(choice2Field.getText().equals("")){
            return false ;
        }else if(choice3Field.getText().equals("")){
            return false ;
        }else if(choice4Field.getText().equals("")){
            return false ;
        }else{
           return true ;
        }
    }

    private void save_in_file(Question[] queArray, String text) {
        text = text + ".txt";
        System.out.println(text);
             try {
                  BufferedWriter writer = new BufferedWriter(new FileWriter("/Users/h41dar21/my_projects/java/ReadQuestion/quizzes/"+text));
                  for (int i = 0; i < queArray.length; i++) {
                  
                  writer.write(queArray[i].question);
                  writer.newLine();
                  
                  writer.write(queArray[i].answer);
                  writer.newLine();
                  
                  writer.write(queArray[i].choice[0]);
                  writer.newLine();
                  
                  writer.write(queArray[i].choice[1]);
                  writer.newLine();
                  
                  writer.write(queArray[i].choice[2]);
                  writer.newLine();
                  
                  writer.write(queArray[i].choice[3]);
                  writer.newLine();
                     
                 }
                  
                  writer.close();
            }catch (Exception ex) {
                  ex.getMessage();
              }
    }
    
}
